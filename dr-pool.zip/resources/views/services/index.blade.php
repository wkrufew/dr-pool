<x-app-layout>

    <section class="bg-white py-6">
        {{-- espacio para bajar un poco el componente de livewire de el listado de todos los servicios --}}
    </section>

    @livewire('services-index')
</x-app-layout>