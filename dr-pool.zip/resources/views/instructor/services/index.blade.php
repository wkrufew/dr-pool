<x-app-layout>
    @livewire('instructor.services-index')
</x-app-layout>